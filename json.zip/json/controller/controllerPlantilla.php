<?php
    class controllerPlantilla{
        static function plantilla()
        {
            require_once "view/plantilla.php";
        }
    }