<?php
    require "plugins/add.php";
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="ilmu-detil.blogspot.com">
    <title>Tutorial CRUD JSON DATA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
</head>

<body>

    </br></br></br></br>
    <div class="container">
        <div class="jumbotron">
            <h3>Muestar de archivos json</h3>

        </div>
    </div>
    <div class="container">

        <!-- boton modal -->

        <div class="mt-5">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
                Agregar nueva publicacion
            </button>
        </div>

        


        </div>
        <br>
        <br>
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <table class="table table-striped table-bordered table-hover">
                        <tr>
                            <th>id</th>
                            <th>Titulo</th>
                            <th>Cuerpo</th>
                            <th style="width:100px;">Fecha</th>
                            <th style="width:130px;">Autor</th>
                            <th style="width:110px;">Acción</th>
                        </tr>
                        <?php $no = 0;
                        foreach ($jsonfile->records as $index => $obj) : $no++;  ?>
                            <tr>
                                <td><?php echo $no; ?></td>
                                <td><?php echo $obj->titulo; ?></td>
                                <td><?php echo $obj->cuerpo; ?></td>
                                <td><?php echo $obj->fecha; ?></td>
                                <td><?php echo $obj->autor; ?></td>
                                <td>
                                    <form action="" method="GET">
                                        <input type="hidden" name="id" value="<?php echo $index; ?>">
                                        <div class="btn-group">
                                            <input type="submit"  class=" btn btn-primary" value="editar">
                                            <a class="btn btn-xs btn-danger" href="delete.php?id=<?php echo $index; ?>"><i class="fa-solid fa-trash"></i></a>
                                        </div>
                                    </form>
                                    
                                    
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </table>

                    <?php require "plugins/modaledit.php"; ?>

                </div>

                <!--fin  boton modal -->
                    <?php require "plugins/modal.php"; ?>
            </div>
        </div>


</body>

</html>