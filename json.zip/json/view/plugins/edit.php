<?php
if (isset($_GET["id"])) {
    $id = (int) $_GET["id"];
    $getfile = file_get_contents('people.json');
    $jsonfile = json_decode($getfile, true);
    $jsonfile = $jsonfile["records"];
    $jsonfile = $jsonfile[$id];
}

if (isset($_POST["id"])) {
    $id = (int) $_POST["id"];
    $getfile = file_get_contents('people.json');
    $all = json_decode($getfile, true);
    $jsonfile = $all["records"];
    $jsonfile = $jsonfile[$id];

    $post["titulo"] = isset($_POST["titulo"]) ? $_POST["titulo"] : "";
    $post["cuerpo"] = isset($_POST["cuerpo"]) ? $_POST["cuerpo"] : "";
    $post["fecha"] = isset($_POST["fecha"]) ? $_POST["fecha"] : "";
    $post["autor"] = isset($_POST["autor"]) ? $_POST["autor"] : "";

    if ($jsonfile) {
        unset($all["records"][$id]);
        $all["records"][$id] = $post;
        $all["records"] = array_values($all["records"]);
        file_put_contents("people.json", json_encode($all));
    }

}