<div class="container">
    <div class="row">
        <div class="row">
            <h3>Zona de edición</h3>
        </div>

        <?php require "edit.php"; ?>

        <?php if (isset($_GET["id"])): ?>
        <form method="POST" action="index.php">

            <input type="hidden" value="<?php echo $id ?>" name="id" />
            <div class="input-group">
                <span class=" input-group-text"><i class="fa fa-user"></i></span>
                <input type="text" class="form-control" required="required" id="titulo" name="titulo"
                    placeholder="titulo" value="<?php echo $jsonfile["titulo"] ?>">
            </div>

            <div class="input-group mt-2">
                <span class="input-group-text"><i class=" fa fa-edit"></i></span>
                <textarea class="form-control" required="required" name="cuerpo" id="cuerpo" cols="30"
                    rows="10"><?php echo $jsonfile["cuerpo"] ?></textarea>
            </div>

            <div class="input-group mt-2">
                <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                <input type="date" required="required" class="form-control" id="fecha" name="fecha" value="<?php echo $jsonfile["fecha"] ?>">
                <span class="input-group-text"><i class="fa fa-users"></i></span>
                <select class="form-control" required="required" id="autor" name="autor">
                    <option>Autor</option>
                    <option value="james mori" <?php echo  $jsonfile["autor"] == 'james mori'?'selected':'';?>>james mori</option>
                    <option value="renzo ramos" <?php echo  $jsonfile["autor"] == 'renzo ramos'?'selected':'';?>>renzo ramos</option>
                    <option value="luis de tomas" <?php echo  $jsonfile["autor"] == 'luis de tomas'?'selected':'';?>>luis de tomas</option>
                </select>
            </div>


            <div class="form-actions mt-2">
                <button type="submit" class="btn btn-success"><i class="fa fa-edit"></i> Editar</button>
            </div>

        </form>
        <?php endif; ?>
    </div>