<?php

    if (!empty($_POST)) 
        {

            $titulo  = $_POST['titulo'];
            $cuerpo  = $_POST['cuerpo'];
            $fecha   = $_POST['fecha'];
            $autor = $_POST['autor'];

            $file = file_get_contents('http://localhost/json/people.json');
            $data = json_decode($file, true);
            unset($_POST["add"]);
            $data["records"] = array_values($data["records"]);
            array_push($data["records"], $_POST);
            file_put_contents("people.json", json_encode($data));
        }

            $getfile = file_get_contents('http://localhost/json/people.json');
            $jsonfile = json_decode($getfile);
