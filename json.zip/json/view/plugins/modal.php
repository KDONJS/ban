        <!-- modal -->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel">Nuevo registro</h4>
                    </div>
                    <div class="modal-body">

                        <form method="POST" action="index.php">
                            <div class="input-group">
                                <span class=" input-group-text"><i class="fa fa-user"></i></span>
                                <input type="text" class="form-control" required="required" id="titulo" name="titulo" placeholder="titulo">
                            </div>

                            <div class="input-group mt-2">
                                <span class="input-group-text"><i class=" fa fa-edit"></i></span>
                                <textarea class="form-control" required="required" name="cuerpo" id="cuerpo" cols="30" rows="10"></textarea>
                            </div>

                            <div class="input-group mt-2">
                                <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                <input type="date" required="required" class="form-control" id="fecha" name="fecha">
                                <span class="input-group-text"><i class="fa fa-users"></i></span>
                                <select class="form-control" required="required" id="autor" name="autor">
                                    <option>Autor</option>
                                    <option value="james mori">james mori</option>
                                    <option value="renzo ramos">renzo ramos</option>
                                    <option value="luis de tomas">luis de tomas</option>
                                </select>
                            </div>
                            

                            <div class="form-actions mt-2">
                                <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> agregar</button>
                            </div>
                        </form>



                    </div>

                </div>
            </div>

            <!-- end modal -->


       