<?php

class modelAdd {
    static function add() {
        
    }
}