<?php
    require "view/plantilla.php";